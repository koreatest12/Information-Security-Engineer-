#!/bin/bash
echo "✅ PATH works! Executed without full path."
