#!/bin/bash
echo "Building Java and Python containers..."
docker-compose build
