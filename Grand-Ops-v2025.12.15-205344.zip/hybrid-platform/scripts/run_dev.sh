#!/bin/bash
echo "Starting stack..."
docker-compose up -d
