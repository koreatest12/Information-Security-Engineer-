print('🚀 DDOS Attack Simulation')
