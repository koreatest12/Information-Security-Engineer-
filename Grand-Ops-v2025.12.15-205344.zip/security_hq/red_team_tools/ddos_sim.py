print('🚀 Launching DDOS Simulation Script...')
