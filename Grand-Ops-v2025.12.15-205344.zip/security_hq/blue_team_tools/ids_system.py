print('🛡️ Activating IPS/IDS System...')
