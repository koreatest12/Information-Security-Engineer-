print('🛡️ IDS Detection System')
