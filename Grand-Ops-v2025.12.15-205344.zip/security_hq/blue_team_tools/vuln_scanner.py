print('🔍 Scanning for Vulnerabilities...')
