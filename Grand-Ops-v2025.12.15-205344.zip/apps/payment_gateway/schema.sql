CREATE TABLE transactions (id INT, amount DECIMAL);
