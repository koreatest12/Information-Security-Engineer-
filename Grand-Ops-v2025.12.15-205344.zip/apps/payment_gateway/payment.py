query='SELECT * FROM tx WHERE id='+id
