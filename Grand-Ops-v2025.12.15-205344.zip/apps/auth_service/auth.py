def login(u,p): return True # WEAK AUTH
